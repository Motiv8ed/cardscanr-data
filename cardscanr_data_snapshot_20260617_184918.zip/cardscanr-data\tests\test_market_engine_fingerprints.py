from __future__ import annotations

from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from cardscanr_market_engine.fingerprints import build_market_price_fingerprint, normalize_market_variant


class FingerprintTests(unittest.TestCase):
    def test_market_variant_aliases_normalize(self) -> None:
        aliases = {
            "raw": "raw",
            "non holo": "non_holo",
            "non-holo": "non_holo",
            "regular": "non_holo",
            "normal": "non_holo",
            "holo": "holo",
            "holographic": "holo",
            "reverse": "reverse_holo",
            "reverse holo": "reverse_holo",
            "reverse-holo": "reverse_holo",
            "rev holo": "reverse_holo",
        }
        for raw, expected in aliases.items():
            self.assertEqual(normalize_market_variant(raw), expected)

    def test_fingerprint_normalizes_and_uses_set_name_fallback(self) -> None:
        fingerprint = build_market_price_fingerprint(
            game=" Pokemon ",
            language=" EN ",
            set_code="",
            set_name="Base Set",
            collector_number=" 4/102 ",
            card_name=" Charizard ",
            variant=" RAW ",
            condition=" Near Mint ",
            market_country=" US ",
            currency=" usd ",
        )
        self.assertEqual(
            fingerprint,
            "pokemon|en|base_set|4/102|charizard|raw|near mint|us|usd",
        )

    def test_fingerprint_is_deterministic(self) -> None:
        left = build_market_price_fingerprint(
            game="pokemon",
            language="en",
            set_code="base1",
            set_name="Base Set",
            collector_number="4",
            card_name="Charizard",
            variant="raw",
            condition="near_mint",
            market_country="us",
            currency="usd",
        )
        right = build_market_price_fingerprint(
            game="pokemon",
            language="en",
            set_code="base1",
            set_name="Base Set",
            collector_number="4",
            card_name="Charizard",
            variant="raw",
            condition="near_mint",
            market_country="us",
            currency="usd",
        )
        self.assertEqual(left, right)

    def test_fingerprint_differs_by_market_country_and_currency(self) -> None:
        common = {
            "game": "pokemon",
            "language": "en",
            "set_code": "base1",
            "set_name": "Base Set",
            "collector_number": "4",
            "card_name": "Charizard",
            "variant": "raw",
            "condition": "near_mint",
        }
        fingerprints = {
            "AU/AUD": build_market_price_fingerprint(**common, market_country="au", currency="aud"),
            "US/USD": build_market_price_fingerprint(**common, market_country="us", currency="usd"),
            "GB/GBP": build_market_price_fingerprint(**common, market_country="gb", currency="gbp"),
            "CA/CAD": build_market_price_fingerprint(**common, market_country="ca", currency="cad"),
        }
        self.assertEqual(len(set(fingerprints.values())), 4)


if __name__ == "__main__":
    unittest.main()
